<?php
return [
    'index' => 'indexController'
];