<?php $__env->startSection('content'); ?>
<h2>Добро пожаловать в блог</h2>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\OSPanel\domains\php\lesson35-36\resources\views/index.blade.php ENDPATH**/ ?>