<a href="<?php echo e(route('home')); ?>">Главная</a>
<a href="<?php echo e(route('posts.index')); ?>">Посты</a>
<a href="<?php echo e(route('admin.index')); ?>">Админка</a>
<br>
<?php /**PATH C:\OSPanel\domains\php\lesson37-38\resources\views/components/menu.blade.php ENDPATH**/ ?>