<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="/styles/app.css">
</head>
<body>
<a href="<?php echo e(route('home')); ?>">Главная</a>
<a href="<?php echo e(route('posts.index')); ?>">Посты</a><br>

<?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /**PATH C:\OSPanel\domains\php\lesson35-36\resources\views/layouts/main.blade.php ENDPATH**/ ?>