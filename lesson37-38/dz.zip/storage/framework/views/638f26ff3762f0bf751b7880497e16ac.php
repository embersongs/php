<?php $__env->startSection('content'); ?>
    <h2>Добро пожаловать в админку</h2>

    <p>Число категорий:</p>
    <p>Число постов:</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\OSPanel\domains\php\lesson37-38\resources\views/admin/index.blade.php ENDPATH**/ ?>