<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="/styles/app.css">
</head>
<body>
<?php echo $__env->make('components.menu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


<?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /**PATH C:\OSPanel\domains\php\lesson37-38\resources\views/layouts/main.blade.php ENDPATH**/ ?>