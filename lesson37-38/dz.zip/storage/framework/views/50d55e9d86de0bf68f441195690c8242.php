<?php $__env->startSection('content'); ?>
<h2><?php echo e($post['title']); ?></h2>
<p><?php echo e($post['content']); ?></p>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\OSPanel\domains\php\lesson35-36\resources\views/post.blade.php ENDPATH**/ ?>